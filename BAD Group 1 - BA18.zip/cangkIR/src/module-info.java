module cangkIR {
	opens apps;
	opens data;
	requires javafx.graphics;
	requires javafx.controls;
	requires java.sql;
	requires javafx.base;
	requires jfxtras.labs;
}